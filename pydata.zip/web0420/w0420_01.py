
for i in range(1,6):
    url='https://comic.naver.com/webtoon/list?titleId=748105&weekday=thu'+'&page='+str(i)
    print(url)