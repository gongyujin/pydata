names=['aaa','bbb','ccc']
ages=[24,18,50]

for (name,age) in zip(names,ages):
    print(name," : ",age)